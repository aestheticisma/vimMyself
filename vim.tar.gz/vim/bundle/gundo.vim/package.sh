#!/usr/bin/env bash

hg archive ~/Desktop/gundo.zip -I 'doc' -I 'plugin' -I 'autoload' -I README.markdown
