
int my_test(void)
{
    return 10;
}

