Vimprj
===========

Vimprj is a Vim plugin that helps you manage options for multiple projects. 

Check details at the [project's page](http://dmitryfrank.com/projects/vimprj)
or read `:help vimprj`.

